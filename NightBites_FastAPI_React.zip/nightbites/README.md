# 🌙 NightBites — Surplus Night Food Deals

Vendors (restaurants, bakeries, street-food stalls) post surplus food before closing.
Customers see a **live countdown** to closing, the **remaining stock**, and **claim a coupon code** (with a QR code).
A deal **auto-expires** when its closing time passes **or** its stock runs out.

**Stack:** FastAPI + SQLAlchemy (SQLite by default; PostgreSQL/MySQL work through `DATABASE_URL`) · React 18 + Vite

---

## Quick start

### 1. Backend (Python 3.10+)
```bash
cd backend
python -m venv venv
# Windows: venv\Scripts\activate    |  Mac/Linux: source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```
On first run, the backend creates the database and loads demo data (3 vendors, 8 live deals).
API docs are at http://localhost:8000/docs

### 2. Frontend (Node 18+)
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173. The dev server forwards `/api` requests to port 8000.

**Demo vendor login:** `demo@nightbites.in` / `demo123`
(also `bakery@nightbites.in` and `chaat@nightbites.in`, same password)

### Single-server mode (production)
```bash
cd frontend && npm run build      # creates frontend/dist (already included in the zip)
cd ../backend && uvicorn app.main:app --host 0.0.0.0 --port 8000
```
FastAPI serves the React app and the API from http://localhost:8000.

---

## Features

**Customers**
- Live deals grid: per-second countdown (green → amber below 1 hour → red, blinking, below 15 minutes)
- Stock bar with "🔥 Only N left" urgency; refreshes every 5 seconds
- Search, category chips, veg-only filter, and sorting (ending soon / biggest discount / lowest price / newest)
- Claim with name + mobile number → unique coupon code `NB-XXXXXX` + QR code; no payment up front
- **My Coupons**: look up coupons by mobile number, grouped into Ready for pickup / Redeemed / Expired

**Vendors**
- Register / login (JWT)
- Post a deal with a live preview: dish, icon, veg/non-veg, prices, portions, closing time (+30m/+1h/+2h/+3h quick buttons), max coupons per customer, pickup window
- Dashboard stats: live deals, claims, pending pickups, redeemed, ₹ revenue recovered
- Per-deal actions: +5 stock, +30 min, stop the deal, view the claims list
- **Redeem coupon**: enter the code → it is validated and marked redeemed (blocks double use and expired coupons)

## Auto-expiry rules
| Rule | How |
|---|---|
| Deal closes at its closing time | Status is computed on every read; claims re-check the time inside an atomic DB update |
| Deal ends when stock reaches 0 | `UPDATE … SET remaining = remaining - 1 WHERE remaining > 0` — concurrent claims can never oversell |
| Coupon expires after the pickup window (closing time + N min) | A background job runs every 20 s, and redeem also checks the time |
| Countdown stays accurate | The client syncs its clock to `server_time` from the API |

## Config (`backend/.env`, optional)
```
DATABASE_URL=sqlite:///./nightbites.db     # e.g. postgresql+psycopg2://user:pass@localhost/nightbites
SECRET_KEY=change-me
SEED_DEMO=true
CORS_ORIGINS=http://localhost:5173
```
Reset the demo data: `python -m app.seed --reset` (run from `backend/`)

## API
| Method | Endpoint | Auth |
|---|---|---|
| GET | `/api/deals?category=&q=&veg=&sort=` | – |
| GET | `/api/deals/{id}` | – |
| POST | `/api/deals/{id}/claim` `{name, phone}` | – |
| GET | `/api/coupons?phone=` · `/api/coupons/{code}` | – |
| GET | `/api/stats` · `/api/meta` | – |
| POST | `/api/auth/register` · `/api/auth/login` · GET `/api/auth/me` | – / JWT |
| GET/POST | `/api/vendor/deals` | JWT |
| PATCH | `/api/vendor/deals/{id}` `{add_stock, closes_at}` | JWT |
| POST | `/api/vendor/deals/{id}/close` | JWT |
| GET | `/api/vendor/deals/{id}/coupons` · `/api/vendor/stats` | JWT |
| POST | `/api/vendor/redeem` `{code}` | JWT |
