import os

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # optional
    pass

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./nightbites.db")
SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-in-production")
TOKEN_HOURS = int(os.getenv("TOKEN_HOURS", "72"))
SEED_DEMO = os.getenv("SEED_DEMO", "true").lower() == "true"
EXPIRY_JOB_SECONDS = int(os.getenv("EXPIRY_JOB_SECONDS", "20"))
CORS_ORIGINS = [o.strip() for o in os.getenv(
    "CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if o.strip()]
