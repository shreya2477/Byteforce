import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .config import CORS_ORIGINS, EXPIRY_JOB_SECONDS, SEED_DEMO
from .database import Base, SessionLocal, engine
from .routers import auth, public, vendor
from .seed import seed
from .services import expire_coupons

log = logging.getLogger("nightbites")


async def expiry_worker():
    """Background job: auto-expire coupons whose pickup window is over.
    Deals auto-expire by rule (time passed OR stock = 0) on every read/claim."""
    while True:
        try:
            db = SessionLocal()
            try:
                n = expire_coupons(db)
                if n:
                    log.info("Expired %s coupons", n)
            finally:
                db.close()
        except Exception as exc:  # keep worker alive
            log.exception("expiry job failed: %s", exc)
        await asyncio.sleep(EXPIRY_JOB_SECONDS)


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    if SEED_DEMO:
        seed()
    task = asyncio.create_task(expiry_worker())
    yield
    task.cancel()


app = FastAPI(title="NightBites API", version="1.0.0",
              description="Surplus night food deals - live countdown, stock & coupons", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

app.include_router(auth.router)
app.include_router(public.router)
app.include_router(vendor.router)


@app.get("/api/health")
def health():
    return {"ok": True}


# Serve the built React app (frontend/dist) if present -> single-server production deploy
DIST = Path(__file__).resolve().parents[2] / "frontend" / "dist"
if DIST.exists():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa(full_path: str):
        file = DIST / full_path
        if full_path and file.is_file():
            return FileResponse(file)
        return FileResponse(DIST / "index.html")
