from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .database import Base


def utcnow() -> datetime:
    """Naive UTC datetime (stored that way in the DB)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Vendor(Base):
    __tablename__ = "vendors"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    shop_name: Mapped[str] = mapped_column(String(160))
    email: Mapped[str] = mapped_column(String(180), unique=True, index=True)
    phone: Mapped[str] = mapped_column(String(20), default="")
    area: Mapped[str] = mapped_column(String(120), default="")
    address: Mapped[str] = mapped_column(String(255), default="")
    password_hash: Mapped[str] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    deals: Mapped[list["Deal"]] = relationship(back_populates="vendor", cascade="all, delete-orphan")


class Deal(Base):
    __tablename__ = "deals"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    vendor_id: Mapped[int] = mapped_column(ForeignKey("vendors.id"), index=True)
    title: Mapped[str] = mapped_column(String(160))
    description: Mapped[str] = mapped_column(Text, default="")
    category: Mapped[str] = mapped_column(String(60), default="Other", index=True)
    emoji: Mapped[str] = mapped_column(String(16), default="🍱")
    image_url: Mapped[str] = mapped_column(String(500), default="")
    veg: Mapped[bool] = mapped_column(Boolean, default=True)
    original_price: Mapped[float] = mapped_column(Float)
    deal_price: Mapped[float] = mapped_column(Float)
    total_stock: Mapped[int] = mapped_column(Integer)
    remaining_stock: Mapped[int] = mapped_column(Integer)
    max_per_customer: Mapped[int] = mapped_column(Integer, default=1)
    pickup_minutes: Mapped[int] = mapped_column(Integer, default=30)
    closes_at: Mapped[datetime] = mapped_column(DateTime, index=True)
    is_cancelled: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    vendor: Mapped[Vendor] = relationship(back_populates="deals")
    coupons: Mapped[list["Coupon"]] = relationship(back_populates="deal", cascade="all, delete-orphan")


class Coupon(Base):
    __tablename__ = "coupons"
    __table_args__ = (UniqueConstraint("code", name="uq_coupon_code"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    deal_id: Mapped[int] = mapped_column(ForeignKey("deals.id"), index=True)
    code: Mapped[str] = mapped_column(String(20), index=True)
    customer_name: Mapped[str] = mapped_column(String(120))
    customer_phone: Mapped[str] = mapped_column(String(20), index=True)
    status: Mapped[str] = mapped_column(String(20), default="active")  # active | redeemed | expired
    valid_until: Mapped[datetime] = mapped_column(DateTime)
    redeemed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)

    deal: Mapped[Deal] = relationship(back_populates="coupons")
