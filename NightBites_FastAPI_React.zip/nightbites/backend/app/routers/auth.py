from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Vendor
from ..schemas import LoginIn, RegisterIn
from ..security import create_token, current_vendor, hash_password, verify_password

router = APIRouter(prefix="/api/auth", tags=["auth"])


def vendor_out(v: Vendor) -> dict:
    return {"id": v.id, "name": v.name, "shop_name": v.shop_name, "email": v.email,
            "phone": v.phone, "area": v.area, "address": v.address}


@router.post("/register")
def register(body: RegisterIn, db: Session = Depends(get_db)):
    email = body.email.lower()
    if db.query(Vendor).filter(Vendor.email == email).first():
        raise HTTPException(409, "An account with this email already exists")
    v = Vendor(name=body.name.strip(), shop_name=body.shop_name.strip(), email=email,
               phone=body.phone.strip(), area=body.area.strip(), address=body.address.strip(),
               password_hash=hash_password(body.password))
    db.add(v)
    db.commit()
    return {"token": create_token(v.id), "vendor": vendor_out(v)}


@router.post("/login")
def login(body: LoginIn, db: Session = Depends(get_db)):
    v = db.query(Vendor).filter(Vendor.email == body.email.lower()).first()
    if not v or not verify_password(body.password, v.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return {"token": create_token(v.id), "vendor": vendor_out(v)}


@router.get("/me")
def me(vendor: Vendor = Depends(current_vendor)):
    return vendor_out(vendor)
