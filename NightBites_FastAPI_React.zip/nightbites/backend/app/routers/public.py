from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..models import Coupon, Deal, Vendor, utcnow
from ..schemas import CATEGORIES, ClaimIn
from ..services import coupon_dict, deal_dict, discount_pct, iso, new_code

router = APIRouter(prefix="/api", tags=["public"])


@router.get("/meta")
def meta():
    return {"categories": CATEGORIES, "server_time": iso(utcnow())}


@router.get("/stats")
def stats(db: Session = Depends(get_db)):
    now = utcnow()
    live = db.query(func.count(Deal.id)).filter(
        Deal.is_cancelled.is_(False), Deal.remaining_stock > 0, Deal.closes_at > now).scalar()
    claimed = db.query(func.count(Coupon.id)).scalar()
    saved = db.query(func.count(Coupon.id)).filter(Coupon.status == "redeemed").scalar()
    vendors = db.query(func.count(Vendor.id)).scalar()
    return {"live_deals": live, "coupons_claimed": claimed, "meals_saved": saved, "vendors": vendors}


@router.get("/deals")
def list_deals(
    db: Session = Depends(get_db),
    category: str | None = None,
    q: str | None = None,
    veg: bool | None = None,
    sort: str = Query("ending", pattern="^(ending|discount|newest|price)$"),
    include_ended: bool = False,
):
    now = utcnow()
    query = db.query(Deal).options(joinedload(Deal.vendor)).join(Vendor)
    if include_ended:
        query = query.filter(Deal.closes_at > now - timedelta(hours=3))
    else:
        query = query.filter(Deal.is_cancelled.is_(False), Deal.remaining_stock > 0, Deal.closes_at > now)
    if category and category != "All":
        query = query.filter(Deal.category == category)
    if veg is not None:
        query = query.filter(Deal.veg.is_(veg))
    if q:
        like = f"%{q.strip()}%"
        query = query.filter(Deal.title.ilike(like) | Deal.description.ilike(like)
                             | Vendor.shop_name.ilike(like) | Vendor.area.ilike(like))
    deals = query.all()
    if sort == "ending":
        deals.sort(key=lambda d: d.closes_at)
    elif sort == "discount":
        deals.sort(key=discount_pct, reverse=True)
    elif sort == "price":
        deals.sort(key=lambda d: d.deal_price)
    else:
        deals.sort(key=lambda d: d.created_at, reverse=True)
    return {"server_time": iso(now), "deals": [deal_dict(d, now) for d in deals]}


@router.get("/deals/{deal_id}")
def get_deal(deal_id: int, db: Session = Depends(get_db)):
    d = db.get(Deal, deal_id)
    if not d:
        raise HTTPException(404, "Deal not found")
    return {"server_time": iso(utcnow()), "deal": deal_dict(d)}


@router.post("/deals/{deal_id}/claim")
def claim(deal_id: int, body: ClaimIn, db: Session = Depends(get_db)):
    now = utcnow()
    deal = db.get(Deal, deal_id)
    if not deal:
        raise HTTPException(404, "Deal not found")
    if deal.is_cancelled:
        raise HTTPException(410, "This deal was cancelled by the vendor")
    if deal.closes_at <= now:
        raise HTTPException(410, "Too late! This deal has expired")
    if deal.remaining_stock <= 0:
        raise HTTPException(410, "Sold out! All portions have been claimed")

    already = db.query(func.count(Coupon.id)).filter(
        Coupon.deal_id == deal_id, Coupon.customer_phone == body.phone,
        Coupon.status != "expired").scalar()
    if already >= deal.max_per_customer:
        raise HTTPException(409, f"Limit reached: max {deal.max_per_customer} coupon(s) per customer for this deal")

    # Atomic stock decrement - safe under concurrent claims
    res = db.execute(
        update(Deal)
        .where(Deal.id == deal_id, Deal.remaining_stock > 0, Deal.closes_at > now,
               Deal.is_cancelled.is_(False))
        .values(remaining_stock=Deal.remaining_stock - 1)
    )
    if res.rowcount == 0:
        db.rollback()
        raise HTTPException(410, "Sold out just now! Someone grabbed the last one")

    coupon = Coupon(deal_id=deal_id, code=new_code(db), customer_name=body.name.strip(),
                    customer_phone=body.phone,
                    valid_until=deal.closes_at + timedelta(minutes=deal.pickup_minutes))
    db.add(coupon)
    try:
        db.commit()  # stock decrement + coupon saved in one transaction
    except IntegrityError:  # near-impossible code collision -> stock restored by rollback
        db.rollback()
        raise HTTPException(503, "Please try again")
    db.refresh(coupon)
    db.refresh(deal)
    return {"coupon": coupon_dict(coupon), "deal": deal_dict(db.get(Deal, deal_id))}


@router.get("/coupons")
def my_coupons(phone: str = Query(min_length=10), db: Session = Depends(get_db)):
    digits = "".join(ch for ch in phone if ch.isdigit())[-10:]
    coupons = (db.query(Coupon).options(joinedload(Coupon.deal).joinedload(Deal.vendor))
               .filter(Coupon.customer_phone == digits).order_by(Coupon.created_at.desc()).limit(50).all())
    return {"server_time": iso(utcnow()), "coupons": [coupon_dict(c) for c in coupons]}


@router.get("/coupons/{code}")
def coupon_by_code(code: str, db: Session = Depends(get_db)):
    c = db.query(Coupon).filter(Coupon.code == code.strip().upper()).first()
    if not c:
        raise HTTPException(404, "Coupon not found")
    return {"server_time": iso(utcnow()), "coupon": coupon_dict(c)}
