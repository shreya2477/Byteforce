from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session, joinedload

from ..database import get_db
from ..models import Coupon, Deal, Vendor, utcnow
from ..schemas import DealIn, DealPatch, RedeemIn
from ..security import current_vendor
from ..services import coupon_dict, deal_dict, iso, to_utc_naive

router = APIRouter(prefix="/api/vendor", tags=["vendor"])


def _own_deal(db: Session, vendor: Vendor, deal_id: int) -> Deal:
    d = db.get(Deal, deal_id)
    if not d or d.vendor_id != vendor.id:
        raise HTTPException(404, "Deal not found")
    return d


def _check_closing(closes_at, now):
    if closes_at <= now + timedelta(minutes=5):
        raise HTTPException(422, "Closing time must be at least 5 minutes from now")
    if closes_at > now + timedelta(hours=24):
        raise HTTPException(422, "Closing time must be within the next 24 hours")


@router.get("/stats")
def vendor_stats(vendor: Vendor = Depends(current_vendor), db: Session = Depends(get_db)):
    now = utcnow()
    base = db.query(Coupon).join(Deal).filter(Deal.vendor_id == vendor.id)
    live = db.query(func.count(Deal.id)).filter(
        Deal.vendor_id == vendor.id, Deal.is_cancelled.is_(False),
        Deal.remaining_stock > 0, Deal.closes_at > now).scalar()
    redeemed = base.filter(Coupon.status == "redeemed")
    recovered = (db.query(func.coalesce(func.sum(Deal.deal_price), 0)).select_from(Coupon).join(Deal)
                 .filter(Deal.vendor_id == vendor.id, Coupon.status == "redeemed").scalar())
    return {
        "live_deals": live,
        "total_deals": db.query(func.count(Deal.id)).filter(Deal.vendor_id == vendor.id).scalar(),
        "claimed": base.count(),
        "pending_pickup": base.filter(Coupon.status == "active").count(),
        "redeemed": redeemed.count(),
        "revenue_recovered": float(recovered or 0),
    }


@router.get("/deals")
def my_deals(vendor: Vendor = Depends(current_vendor), db: Session = Depends(get_db)):
    now = utcnow()
    deals = (db.query(Deal).options(joinedload(Deal.vendor)).filter(Deal.vendor_id == vendor.id)
             .order_by(Deal.created_at.desc()).limit(100).all())
    out = []
    for d in deals:
        item = deal_dict(d, now)
        item["redeemed"] = sum(1 for c in d.coupons if c.status == "redeemed")
        out.append(item)
    return {"server_time": iso(now), "deals": out}


@router.post("/deals", status_code=201)
def create_deal(body: DealIn, vendor: Vendor = Depends(current_vendor), db: Session = Depends(get_db)):
    now = utcnow()
    closes_at = to_utc_naive(body.closes_at)
    _check_closing(closes_at, now)
    if body.deal_price >= body.original_price:
        raise HTTPException(422, "Deal price must be lower than the original price")
    d = Deal(vendor_id=vendor.id, title=body.title.strip(), description=body.description.strip(),
             category=body.category, emoji=body.emoji or "🍱", image_url=body.image_url.strip(),
             veg=body.veg, original_price=body.original_price, deal_price=body.deal_price,
             total_stock=body.total_stock, remaining_stock=body.total_stock,
             max_per_customer=body.max_per_customer, pickup_minutes=body.pickup_minutes,
             closes_at=closes_at)
    db.add(d)
    db.commit()
    db.refresh(d)
    return {"deal": deal_dict(d)}


@router.patch("/deals/{deal_id}")
def update_deal(deal_id: int, body: DealPatch, vendor: Vendor = Depends(current_vendor),
                db: Session = Depends(get_db)):
    d = _own_deal(db, vendor, deal_id)
    if d.is_cancelled:
        raise HTTPException(400, "Cancelled deals cannot be edited")
    if body.add_stock:
        d.total_stock += body.add_stock
        d.remaining_stock += body.add_stock
    if body.closes_at:
        closes_at = to_utc_naive(body.closes_at)
        _check_closing(closes_at, utcnow())
        d.closes_at = closes_at
        # keep pickup window of already issued (active) coupons in sync
        for c in d.coupons:
            if c.status == "active":
                c.valid_until = closes_at + timedelta(minutes=d.pickup_minutes)
    db.commit()
    return {"deal": deal_dict(d)}


@router.post("/deals/{deal_id}/close")
def close_deal(deal_id: int, vendor: Vendor = Depends(current_vendor), db: Session = Depends(get_db)):
    """Stop new claims now. Already issued coupons stay valid for their pickup window."""
    d = _own_deal(db, vendor, deal_id)
    d.is_cancelled = True
    db.commit()
    return {"deal": deal_dict(d)}


@router.get("/deals/{deal_id}/coupons")
def deal_coupons(deal_id: int, vendor: Vendor = Depends(current_vendor), db: Session = Depends(get_db)):
    d = _own_deal(db, vendor, deal_id)
    coupons = sorted(d.coupons, key=lambda c: c.created_at, reverse=True)
    return {"deal": deal_dict(d), "coupons": [coupon_dict(c) for c in coupons]}


@router.post("/redeem")
def redeem(body: RedeemIn, vendor: Vendor = Depends(current_vendor), db: Session = Depends(get_db)):
    code = body.code.strip().upper()
    if not code.startswith("NB-"):
        code = "NB-" + code
    c = db.query(Coupon).join(Deal).filter(Coupon.code == code).first()
    if not c or c.deal.vendor_id != vendor.id:
        raise HTTPException(404, "No coupon with this code for your shop")
    now = utcnow()
    if c.status == "redeemed":
        raise HTTPException(409, f"Already redeemed at {iso(c.redeemed_at)}")
    if c.status == "expired" or c.valid_until <= now:
        c.status = "expired"
        db.commit()
        raise HTTPException(410, "This coupon has expired (pickup window over)")
    c.status = "redeemed"
    c.redeemed_at = now
    db.commit()
    return {"coupon": coupon_dict(c)}
