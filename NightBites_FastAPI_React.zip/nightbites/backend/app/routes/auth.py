from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Vendor
from ..schemas import LoginIn, RegisterIn
from ..security import create_token, current_vendor, hash_password, verify_password
from ..services import iso, utcnow

router = APIRouter(prefix="/api/auth", tags=["auth"])


def vendor_out(v: Vendor) -> dict:
    return {
        "id": v.id, "name": v.name, "email": v.email, "shop_name": v.shop_name,
        "address": v.address, "phone": v.phone, "created_at": iso(v.created_at),
    }


@router.post("/register")
def register(body: RegisterIn, db: Session = Depends(get_db)):
    if db.query(Vendor).filter(Vendor.email == body.email).first():
        raise HTTPException(409, "An account with this email already exists")
    v = Vendor(
        name=body.name.strip(), email=body.email, password_hash=hash_password(body.password),
        shop_name=body.shop_name.strip(), address=body.address.strip(), phone=body.phone,
        created_at=utcnow(),
    )
    db.add(v)
    db.commit()
    db.refresh(v)
    return {"token": create_token(v.id), "vendor": vendor_out(v)}


@router.post("/login")
def login(body: LoginIn, db: Session = Depends(get_db)):
    v = db.query(Vendor).filter(Vendor.email == body.email.strip().lower()).first()
    if not v or not verify_password(body.password, v.password_hash):
        raise HTTPException(401, "Invalid email or password")
    return {"token": create_token(v.id), "vendor": vendor_out(v)}


@router.get("/me")
def me(vendor: Vendor = Depends(current_vendor)):
    return vendor_out(vendor)
