from datetime import datetime

from pydantic import BaseModel, EmailStr, Field, field_validator

CATEGORIES = ["Biryani", "Bakery", "Pizza", "Street Food", "Desserts", "Thali", "Chinese", "Cafe", "Other"]


class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    shop_name: str = Field(min_length=2, max_length=160)
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)
    phone: str = Field(default="", max_length=20)
    area: str = Field(default="", max_length=120)
    address: str = Field(default="", max_length=255)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class DealIn(BaseModel):
    title: str = Field(min_length=3, max_length=160)
    description: str = Field(default="", max_length=1000)
    category: str = "Other"
    emoji: str = Field(default="🍱", max_length=16)
    image_url: str = Field(default="", max_length=500)
    veg: bool = True
    original_price: float = Field(gt=0, le=100000)
    deal_price: float = Field(ge=0, le=100000)
    total_stock: int = Field(ge=1, le=1000)
    max_per_customer: int = Field(default=1, ge=1, le=10)
    pickup_minutes: int = Field(default=30, ge=5, le=180)
    closes_at: datetime

    @field_validator("category")
    @classmethod
    def valid_category(cls, v: str) -> str:
        return v if v in CATEGORIES else "Other"


class DealPatch(BaseModel):
    add_stock: int | None = Field(default=None, ge=1, le=1000)
    closes_at: datetime | None = None


class ClaimIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    phone: str = Field(min_length=10, max_length=15)

    @field_validator("phone")
    @classmethod
    def digits_only(cls, v: str) -> str:
        digits = "".join(ch for ch in v if ch.isdigit())
        if len(digits) < 10:
            raise ValueError("Enter a valid 10-digit mobile number")
        return digits[-10:]


class RedeemIn(BaseModel):
    code: str = Field(min_length=4, max_length=20)
