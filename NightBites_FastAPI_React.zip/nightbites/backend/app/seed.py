"""Demo data so the app looks alive on first run. Run: python -m app.seed --reset"""
import sys
from datetime import timedelta

from .database import Base, SessionLocal, engine
from .models import Coupon, Deal, Vendor, utcnow
from .services import new_code
from .security import hash_password

VENDORS = [
    ("Arjun Mehta", "Biryani Junction", "demo@nightbites.in", "9876500001", "MP Nagar", "Zone-II, MP Nagar, Bhopal"),
    ("Sana Khan", "Crust & Crumb Bakery", "bakery@nightbites.in", "9876500002", "Arera Colony", "E-5, Arera Colony, Bhopal"),
    ("Rohit Verma", "Midnight Chaat Co.", "chaat@nightbites.in", "9876500003", "New Market", "TT Nagar, New Market, Bhopal"),
]

# (vendor_idx, title, desc, category, emoji, veg, orig, price, stock, closes_in_min)
NAMES = ["Aman", "Neha", "Vikram", "Pooja", "Rahul", "Sneha"]

DEALS = [
    (0, "Chicken Dum Biryani (Full)", "Slow-cooked handi biryani with raita & salan. Fresh batch from dinner service.", "Biryani", "🍗", False, 280, 119, 12, 95),
    (0, "Veg Hyderabadi Biryani", "Aromatic basmati, seasonal veggies, fried onions. Packed hot.", "Biryani", "🍛", True, 220, 89, 8, 140),
    (1, "Surprise Bakery Box", "Mix of 4-5 croissants, muffins and garlic buns baked today.", "Bakery", "🥐", True, 450, 149, 15, 60),
    (1, "Belgian Chocolate Pastries x2", "Two pastries from today's display counter.", "Desserts", "🍰", True, 240, 99, 10, 185),
    (1, "Sourdough Loaf", "Naturally leavened, baked this morning. Perfect for breakfast.", "Bakery", "🍞", True, 180, 69, 6, 35),
    (2, "Pani Puri Party Pack", "30 puris with spicy & sweet pani, masala filling packed separately.", "Street Food", "🥟", True, 150, 59, 20, 75),
    (2, "Pav Bhaji Combo", "Butter pav bhaji for 2 with onion & lemon.", "Street Food", "🍲", True, 200, 89, 9, 220),
    (0, "Mini Thali Dinner", "Dal, sabzi, jeera rice, 3 rotis and gulab jamun.", "Thali", "🍱", True, 180, 79, 14, 120),
]


def seed(reset: bool = False) -> None:
    if reset:
        Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(Vendor).count():
            return
        pw = hash_password("demo123")
        vendors = [Vendor(name=n, shop_name=s, email=e, phone=p, area=a, address=ad, password_hash=pw)
                   for n, s, e, p, a, ad in VENDORS]
        db.add_all(vendors)
        db.flush()
        now = utcnow()
        for vi, title, desc, cat, emo, veg, orig, price, stock, mins in DEALS:
            claimed = stock // 3
            deal = Deal(vendor_id=vendors[vi].id, title=title, description=desc, category=cat, emoji=emo,
                        veg=veg, original_price=orig, deal_price=price, total_stock=stock,
                        remaining_stock=stock - claimed, closes_at=now + timedelta(minutes=mins),
                        created_at=now - timedelta(minutes=30 - vi))
            db.add(deal)
            db.flush()
            for i in range(claimed):  # realistic demo claims
                db.add(Coupon(deal_id=deal.id, code=new_code(db), customer_name=NAMES[i % len(NAMES)],
                              customer_phone=f"98{deal.id:03d}{i:05d}",
                              valid_until=deal.closes_at + timedelta(minutes=deal.pickup_minutes),
                              created_at=now - timedelta(minutes=20 - i)))
                db.flush()
        db.commit()
        print("Seeded demo data. Vendor login: demo@nightbites.in / demo123")
    finally:
        db.close()


if __name__ == "__main__":
    seed(reset="--reset" in sys.argv)
