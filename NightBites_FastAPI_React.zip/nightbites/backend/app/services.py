"""Shared helpers: time handling, serialization, status rules, expiry job."""
import secrets
from datetime import datetime, timezone

from sqlalchemy import update
from sqlalchemy.orm import Session

from .models import Coupon, Deal, utcnow

CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # no 0/O/1/I confusion


def to_utc_naive(dt: datetime) -> datetime:
    if dt.tzinfo is None:  # treat naive input as UTC
        return dt
    return dt.astimezone(timezone.utc).replace(tzinfo=None)


def iso(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    return dt.replace(tzinfo=timezone.utc).isoformat().replace("+00:00", "Z")


def deal_status(deal: Deal, now: datetime | None = None) -> str:
    now = now or utcnow()
    if deal.is_cancelled:
        return "cancelled"
    if deal.remaining_stock <= 0:
        return "sold_out"
    if deal.closes_at <= now:
        return "expired"
    return "live"


def discount_pct(deal: Deal) -> int:
    if deal.original_price <= 0:
        return 0
    return max(0, round((1 - deal.deal_price / deal.original_price) * 100))


def deal_dict(deal: Deal, now: datetime | None = None) -> dict:
    now = now or utcnow()
    v = deal.vendor
    return {
        "id": deal.id,
        "title": deal.title,
        "description": deal.description,
        "category": deal.category,
        "emoji": deal.emoji,
        "image_url": deal.image_url,
        "veg": deal.veg,
        "original_price": deal.original_price,
        "deal_price": deal.deal_price,
        "discount_pct": discount_pct(deal),
        "total_stock": deal.total_stock,
        "remaining_stock": max(0, deal.remaining_stock),
        "claimed": deal.total_stock - max(0, deal.remaining_stock),
        "max_per_customer": deal.max_per_customer,
        "pickup_minutes": deal.pickup_minutes,
        "closes_at": iso(deal.closes_at),
        "created_at": iso(deal.created_at),
        "status": deal_status(deal, now),
        "seconds_left": max(0, int((deal.closes_at - now).total_seconds())),
        "vendor": {
            "id": v.id, "shop_name": v.shop_name, "area": v.area,
            "address": v.address, "phone": v.phone,
        } if v else None,
    }


def coupon_dict(c: Coupon) -> dict:
    d = c.deal
    return {
        "id": c.id,
        "code": c.code,
        "customer_name": c.customer_name,
        "customer_phone": c.customer_phone,
        "status": c.status,
        "valid_until": iso(c.valid_until),
        "redeemed_at": iso(c.redeemed_at),
        "created_at": iso(c.created_at),
        "deal": {
            "id": d.id, "title": d.title, "emoji": d.emoji, "deal_price": d.deal_price,
            "original_price": d.original_price, "shop_name": d.vendor.shop_name,
            "area": d.vendor.area, "address": d.vendor.address,
        } if d else None,
    }


def new_code(db: Session) -> str:
    while True:
        code = "NB-" + "".join(secrets.choice(CODE_ALPHABET) for _ in range(6))
        if not db.query(Coupon.id).filter(Coupon.code == code).first():
            return code


def expire_coupons(db: Session) -> int:
    """Mark active coupons past their pickup window as expired."""
    res = db.execute(
        update(Coupon)
        .where(Coupon.status == "active", Coupon.valid_until <= utcnow())
        .values(status="expired")
    )
    db.commit()
    return res.rowcount or 0
