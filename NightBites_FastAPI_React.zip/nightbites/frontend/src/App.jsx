import { Navigate, Route, Routes } from 'react-router-dom'
import Navbar from './components/Navbar'
import { ToastProvider } from './components/Toast'
import Home from './pages/Home'
import MyCoupons from './pages/MyCoupons'
import VendorAuth from './pages/VendorAuth'
import VendorDashboard from './pages/VendorDashboard'

export default function App() {
  return (
    <ToastProvider>
      <div className="sky" aria-hidden="true">
        <div className="moon" />
        <div className="stars" />
      </div>
      <Navbar />
      <main className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/coupons" element={<MyCoupons />} />
          <Route path="/vendor/login" element={<VendorAuth />} />
          <Route path="/vendor" element={<VendorDashboard />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
      <footer className="footer">
        🌙 NightBites — good food shouldn't go to waste. Save money, save meals.
      </footer>
    </ToastProvider>
  )
}
