const BASE = import.meta.env.VITE_API_URL || ''

// Server clock offset, so countdowns are correct even if the user's clock is off
let offset = 0
export const serverNow = () => Date.now() + offset
function syncClock(data) {
  if (data && data.server_time) offset = new Date(data.server_time).getTime() - Date.now()
}

export const auth = {
  get token() { return localStorage.getItem('nb_token') },
  get vendor() {
    try { return JSON.parse(localStorage.getItem('nb_vendor') || 'null') } catch { return null }
  },
  save(token, vendor) {
    localStorage.setItem('nb_token', token)
    localStorage.setItem('nb_vendor', JSON.stringify(vendor))
  },
  clear() { localStorage.removeItem('nb_token'); localStorage.removeItem('nb_vendor') },
}

export async function api(path, { method = 'GET', body, authed = false } = {}) {
  const headers = { 'Content-Type': 'application/json' }
  if (authed && auth.token) headers.Authorization = `Bearer ${auth.token}`
  let res
  try {
    res = await fetch(`${BASE}/api${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined })
  } catch {
    throw new Error('Cannot reach server. Is the backend running?')
  }
  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    if (res.status === 401 && authed) { auth.clear(); window.dispatchEvent(new Event('nb-auth')) }
    let msg = data.detail
    if (Array.isArray(msg)) msg = msg.map((e) => e.msg?.replace('Value error, ', '')).join(', ')
    throw new Error(msg || `Request failed (${res.status})`)
  }
  syncClock(data)
  return data
}
