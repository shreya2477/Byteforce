import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api'
import { rupee } from '../hooks'
import Countdown from './Countdown'
import CouponTicket from './CouponTicket'

export default function ClaimModal({ deal, onClose, onClaimed }) {
  const [name, setName] = useState(localStorage.getItem('nb_name') || '')
  const [phone, setPhone] = useState(localStorage.getItem('nb_phone') || '')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [coupon, setCoupon] = useState(null)

  useEffect(() => {
    const esc = (e) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', esc)
    document.body.style.overflow = 'hidden'
    return () => { window.removeEventListener('keydown', esc); document.body.style.overflow = '' }
  }, [onClose])

  const submit = async (e) => {
    e.preventDefault()
    setError('')
    if (!/^\d{10}$/.test(phone.replace(/\D/g, '').slice(-10))) return setError('Enter a valid 10-digit mobile number')
    setBusy(true)
    try {
      const res = await api(`/deals/${deal.id}/claim`, { method: 'POST', body: { name, phone } })
      localStorage.setItem('nb_name', name)
      localStorage.setItem('nb_phone', res.coupon.customer_phone)
      setCoupon(res.coupon)
      onClaimed?.(res.deal)
    } catch (err) {
      setError(err.message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="modal-bg" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true">
        <button className="modal-x" onClick={onClose} aria-label="Close">×</button>
        {coupon ? (
          <div className="claimed">
            <div className="confetti">🎉</div>
            <h2>Coupon claimed!</h2>
            <p className="muted">Show this code at the counter and pay {rupee(deal.deal_price)}.</p>
            <CouponTicket coupon={coupon} />
            <div className="row gap">
              <Link to="/coupons" className="btn btn-ghost" onClick={onClose}>View my coupons</Link>
              <button className="btn btn-primary" onClick={onClose}>Done</button>
            </div>
          </div>
        ) : (
          <>
            <div className="modal-head">
              <span className="modal-emoji">{deal.emoji}</span>
              <div>
                <h2>{deal.title}</h2>
                <p className="muted">🏪 {deal.vendor?.shop_name} · {deal.vendor?.area}</p>
              </div>
            </div>
            <div className="modal-strip">
              <div><span className="price">{rupee(deal.deal_price)}</span> <s className="muted">{rupee(deal.original_price)}</s></div>
              <div className="muted small">{deal.remaining_stock} left · <Countdown variant="inline" to={deal.closes_at} /></div>
            </div>
            <form onSubmit={submit} className="form">
              <label>Your name
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Priya Sharma" required minLength={2} />
              </label>
              <label>Mobile number
                <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="10-digit mobile" inputMode="numeric" required />
              </label>
              {error && <div className="alert">{error}</div>}
              <button className="btn btn-primary btn-block btn-lg" disabled={busy}>
                {busy ? 'Reserving…' : '🎟️ Reserve & get coupon'}
              </button>
              <p className="tiny muted center">No payment now. Pay at the shop within {deal.pickup_minutes} min after closing.</p>
            </form>
          </>
        )}
      </div>
    </div>
  )
}
