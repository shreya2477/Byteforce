import { pad, splitTime, useNow } from '../hooks'

/** Live countdown to `to` (ISO). variant: "blocks" | "inline" */
export default function Countdown({ to, variant = 'blocks', label = 'Closes in' }) {
  const now = useNow()
  const { h, m, s, total } = splitTime(new Date(to).getTime() - now)
  const level = total === 0 ? 'over' : total < 15 * 60 ? 'hot' : total < 60 * 60 ? 'warm' : 'cool'

  if (variant === 'inline') {
    return (
      <span className={`cd-inline cd-${level}`}>
        {total === 0 ? 'Ended' : `${h ? h + 'h ' : ''}${pad(m)}m ${pad(s)}s`}
      </span>
    )
  }
  return (
    <div className={`countdown cd-${level}`}>
      <span className="cd-label">{total === 0 ? 'Closed' : label}</span>
      <div className="cd-blocks">
        <span><b>{pad(h)}</b><i>hr</i></span>
        <em>:</em>
        <span><b>{pad(m)}</b><i>min</i></span>
        <em>:</em>
        <span><b>{pad(s)}</b><i>sec</i></span>
      </div>
    </div>
  )
}
