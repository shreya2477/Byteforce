import { useState } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import Countdown from './Countdown'
import { rupee, timeOf, useNow } from '../hooks'

export default function CouponTicket({ coupon, compact = false }) {
  const now = useNow()
  const [copied, setCopied] = useState(false)
  const d = coupon.deal
  const lapsed = coupon.status === 'active' && new Date(coupon.valid_until).getTime() <= now
  const status = lapsed ? 'expired' : coupon.status

  const copy = async () => {
    try { await navigator.clipboard.writeText(coupon.code); setCopied(true); setTimeout(() => setCopied(false), 1500) } catch { /* ignore */ }
  }

  return (
    <div className={`ticket ticket-${status} ${compact ? 'ticket-compact' : ''}`}>
      <div className="ticket-left">
        <div className="ticket-head">
          <span className="ticket-emoji">{d?.emoji}</span>
          <div>
            <h4>{d?.title}</h4>
            <p className="muted small">🏪 {d?.shop_name} · {d?.area}</p>
          </div>
        </div>
        <div className="ticket-code" onClick={copy} title="Click to copy">
          {coupon.code}
          <span className="copy-hint">{copied ? 'Copied!' : 'Copy'}</span>
        </div>
        <div className="ticket-meta">
          <span>Pay at pickup: <b>{rupee(d?.deal_price)}</b> <s className="muted">{rupee(d?.original_price)}</s></span>
          {status === 'active' && <span>Valid till <b>{timeOf(coupon.valid_until)}</b> · <Countdown variant="inline" to={coupon.valid_until} /></span>}
          {status === 'redeemed' && <span>✅ Redeemed at {timeOf(coupon.redeemed_at)}</span>}
          {status === 'expired' && <span>⌛ Pickup window ended</span>}
        </div>
        {d?.address && !compact && <p className="tiny muted">📍 {d.address}</p>}
      </div>
      <div className="ticket-right">
        <div className="qr"><QRCodeSVG value={coupon.code} size={compact ? 78 : 104} bgColor="#ffffff" fgColor="#0b0d1a" /></div>
        <span className={`status-pill s-${status}`}>{status}</span>
      </div>
    </div>
  )
}
