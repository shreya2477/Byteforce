import Countdown from './Countdown'
import StockBar from './StockBar'
import { rupee, timeOf, useNow } from '../hooks'

const HUES = { Biryani: 28, Bakery: 38, Pizza: 8, 'Street Food': 340, Desserts: 320, Thali: 48, Chinese: 0, Cafe: 25, Other: 260 }

export default function DealCard({ deal, onClaim }) {
  const now = useNow()
  const timeUp = new Date(deal.closes_at).getTime() <= now
  const status = deal.status !== 'live' ? deal.status : timeUp ? 'expired' : 'live'
  const hue = HUES[deal.category] ?? 260
  const disabled = status !== 'live'

  return (
    <article className={`card deal ${disabled ? 'is-off' : ''}`} style={{ '--hue': hue }}>
      <div className="deal-media">
        {deal.image_url ? <img src={deal.image_url} alt="" loading="lazy" /> : <span className="deal-emoji">{deal.emoji}</span>}
        <span className="badge-off">{deal.discount_pct}% OFF</span>
        <span className={`veg-dot ${deal.veg ? 'veg' : 'nonveg'}`} title={deal.veg ? 'Veg' : 'Non-veg'} />
        {disabled && (
          <div className="deal-overlay">
            {status === 'sold_out' ? 'SOLD OUT' : status === 'cancelled' ? 'CLOSED' : 'EXPIRED'}
          </div>
        )}
      </div>
      <div className="deal-body">
        <div className="deal-shop">
          <span>🏪 {deal.vendor?.shop_name}</span>
          <span className="muted">📍 {deal.vendor?.area}</span>
        </div>
        <h3>{deal.title}</h3>
        {deal.description && <p className="deal-desc">{deal.description}</p>}
        <div className="price-row">
          <span className="price">{rupee(deal.deal_price)}</span>
          <s className="muted">{rupee(deal.original_price)}</s>
          <span className="chip">{deal.category}</span>
        </div>
        <Countdown to={deal.closes_at} />
        <StockBar remaining={deal.remaining_stock} total={deal.total_stock} />
        <button className="btn btn-primary btn-block" disabled={disabled} onClick={() => onClaim(deal)}>
          {disabled ? 'Not available' : '🎟️ Claim coupon'}
        </button>
        <p className="tiny muted center">Pick up by {timeOf(new Date(new Date(deal.closes_at).getTime() + deal.pickup_minutes * 60000).toISOString())}</p>
      </div>
    </article>
  )
}
