import { useEffect, useState } from 'react'
import { NavLink, Link } from 'react-router-dom'
import { auth } from '../api'

export default function Navbar() {
  const [vendor, setVendor] = useState(auth.vendor)
  useEffect(() => {
    const sync = () => setVendor(auth.vendor)
    window.addEventListener('nb-auth', sync)
    return () => window.removeEventListener('nb-auth', sync)
  }, [])

  return (
    <header className="nav">
      <div className="container nav-inner">
        <Link to="/" className="brand">
          <span className="brand-moon">🌙</span>
          <span>Night<b>Bites</b></span>
        </Link>
        <nav className="nav-links">
          <NavLink to="/" end>Deals</NavLink>
          <NavLink to="/coupons">My Coupons</NavLink>
          {vendor ? (
            <NavLink to="/vendor" className="nav-cta">🏪 {vendor.shop_name}</NavLink>
          ) : (
            <NavLink to="/vendor/login" className="nav-cta">For Vendors</NavLink>
          )}
        </nav>
      </div>
    </header>
  )
}
