export default function StockBar({ remaining, total }) {
  const pct = total ? Math.round((remaining / total) * 100) : 0
  const level = remaining === 0 ? 'none' : pct <= 25 ? 'low' : pct <= 50 ? 'mid' : 'high'
  return (
    <div className={`stock stock-${level}`}>
      <div className="stock-top">
        <span>
          {remaining === 0 ? 'Sold out' : remaining <= 3 ? `🔥 Only ${remaining} left!` : `${remaining} left`}
        </span>
        <span className="muted">{total - remaining}/{total} claimed</span>
      </div>
      <div className="stock-track"><div className="stock-fill" style={{ width: `${pct}%` }} /></div>
    </div>
  )
}
