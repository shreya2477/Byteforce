import { useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { serverNow } from './api'

// One shared 1-second ticker for every countdown on the page
const listeners = new Set()
let now = serverNow()
setInterval(() => { now = serverNow(); listeners.forEach((l) => l()) }, 1000)
const subscribe = (l) => { listeners.add(l); return () => listeners.delete(l) }

export function useNow() {
  return useSyncExternalStore(subscribe, () => now)
}

export function usePolling(fn, ms, deps = []) {
  const saved = useRef(fn)
  saved.current = fn
  useEffect(() => {
    saved.current()
    const id = setInterval(() => { if (!document.hidden) saved.current() }, ms)
    const onVis = () => { if (!document.hidden) saved.current() }
    document.addEventListener('visibilitychange', onVis)
    return () => { clearInterval(id); document.removeEventListener('visibilitychange', onVis) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
}

export function useLocal(key, initial) {
  const [v, setV] = useState(() => localStorage.getItem(key) ?? initial)
  useEffect(() => { v ? localStorage.setItem(key, v) : localStorage.removeItem(key) }, [key, v])
  return [v, setV]
}

export function splitTime(ms) {
  const s = Math.max(0, Math.floor(ms / 1000))
  return { h: Math.floor(s / 3600), m: Math.floor((s % 3600) / 60), s: s % 60, total: s }
}

export const pad = (n) => String(n).padStart(2, '0')
export const rupee = (n) => '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 0 })
export const timeOf = (iso) =>
  new Date(iso).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true })
