import { useCallback, useEffect, useState } from 'react'
import { api } from '../api'
import { usePolling } from '../hooks'
import DealCard from '../components/DealCard'
import ClaimModal from '../components/ClaimModal'

const CAT_ICONS = { All: '✨', Biryani: '🍛', Bakery: '🥐', Pizza: '🍕', 'Street Food': '🥟', Desserts: '🍰', Thali: '🍱', Chinese: '🥡', Cafe: '☕', Other: '🍽️' }

export default function Home() {
  const [deals, setDeals] = useState([])
  const [stats, setStats] = useState(null)
  const [cats, setCats] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [category, setCategory] = useState('All')
  const [q, setQ] = useState('')
  const [debQ, setDebQ] = useState('')
  const [veg, setVeg] = useState(false)
  const [sort, setSort] = useState('ending')
  const [active, setActive] = useState(null)

  useEffect(() => { api('/meta').then((m) => setCats(['All', ...m.categories])).catch(() => {}) }, [])
  useEffect(() => { const t = setTimeout(() => setDebQ(q), 300); return () => clearTimeout(t) }, [q])

  const load = useCallback(async () => {
    const p = new URLSearchParams({ sort })
    if (category !== 'All') p.set('category', category)
    if (debQ) p.set('q', debQ)
    if (veg) p.set('veg', 'true')
    try {
      const [d, s] = await Promise.all([api(`/deals?${p}`), api('/stats')])
      setDeals(d.deals); setStats(s); setError('')
    } catch (e) { setError(e.message) } finally { setLoading(false) }
  }, [category, debQ, veg, sort])

  // live refresh: stock + new deals every 5s; countdown ticks every 1s client-side
  usePolling(load, 5000, [load])

  const onClaimed = (updated) => setDeals((xs) => xs.map((d) => (d.id === updated.id ? { ...d, ...updated } : d)))

  return (
    <>
      <section className="hero">
        <div className="hero-text">
          <span className="eyebrow"><span className="live-dot" /> Live tonight</span>
          <h1>Late-night food,<br /><em>up to 70% off.</em></h1>
          <p className="lead">Restaurants & bakeries post their surplus before closing. Grab a coupon, pick it up, pay less — and keep good food out of the bin.</p>
          <div className="hero-stats">
            <div><b>{stats?.live_deals ?? '–'}</b><span>live deals</span></div>
            <div><b>{stats?.coupons_claimed ?? '–'}</b><span>coupons claimed</span></div>
            <div><b>{stats?.meals_saved ?? '–'}</b><span>meals rescued</span></div>
          </div>
        </div>
        <div className="hero-art" aria-hidden="true">
          <div className="plate p1">🍛</div><div className="plate p2">🥐</div><div className="plate p3">🍕</div><div className="plate p4">🍰</div>
        </div>
      </section>

      <section className="toolbar card">
        <div className="search">
          <span>🔎</span>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search dish, shop or area…" />
        </div>
        <label className="switch">
          <input type="checkbox" checked={veg} onChange={(e) => setVeg(e.target.checked)} />
          <span className="switch-ui" /> Veg only
        </label>
        <select value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="ending">⏳ Ending soon</option>
          <option value="discount">💸 Biggest discount</option>
          <option value="price">🪙 Lowest price</option>
          <option value="newest">🆕 Newest</option>
        </select>
      </section>

      <div className="chips">
        {cats.map((c) => (
          <button key={c} className={`chip-btn ${category === c ? 'on' : ''}`} onClick={() => setCategory(c)}>
            {CAT_ICONS[c] || '🍽️'} {c}
          </button>
        ))}
      </div>

      {error && <div className="alert">{error}</div>}
      {loading ? (
        <div className="grid">{[1, 2, 3, 4, 5, 6].map((i) => <div key={i} className="card skeleton" />)}</div>
      ) : deals.length === 0 ? (
        <div className="empty card">
          <div className="empty-emoji">🌙</div>
          <h3>No live deals right now</h3>
          <p className="muted">Vendors post surplus food closer to closing time. Check back in a bit!</p>
        </div>
      ) : (
        <div className="grid">
          {deals.map((d) => <DealCard key={d.id} deal={d} onClaim={setActive} />)}
        </div>
      )}

      {active && <ClaimModal deal={active} onClose={() => { setActive(null); load() }} onClaimed={onClaimed} />}
    </>
  )
}
