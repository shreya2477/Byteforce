import { useCallback, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api'
import { usePolling } from '../hooks'
import CouponTicket from '../components/CouponTicket'

export default function MyCoupons() {
  const [phone, setPhone] = useState(localStorage.getItem('nb_phone') || '')
  const [query, setQuery] = useState(localStorage.getItem('nb_phone') || '')
  const [coupons, setCoupons] = useState(null)
  const [error, setError] = useState('')

  const load = useCallback(async () => {
    if (!query) return
    try {
      const r = await api(`/coupons?phone=${encodeURIComponent(query)}`)
      setCoupons(r.coupons); setError('')
    } catch (e) { setError(e.message) }
  }, [query])
  usePolling(load, 10000, [load])

  const submit = (e) => {
    e.preventDefault()
    const digits = phone.replace(/\D/g, '').slice(-10)
    if (digits.length !== 10) return setError('Enter a valid 10-digit mobile number')
    localStorage.setItem('nb_phone', digits)
    setQuery(digits)
  }

  const groups = { active: [], redeemed: [], expired: [] }
  ;(coupons || []).forEach((c) => groups[c.status]?.push(c))

  return (
    <section className="page">
      <div className="page-head">
        <h1>🎟️ My Coupons</h1>
        <p className="muted">Enter the mobile number you used while claiming.</p>
      </div>
      <form onSubmit={submit} className="card lookup">
        <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="10-digit mobile number" inputMode="numeric" />
        <button className="btn btn-primary">Find coupons</button>
      </form>
      {error && <div className="alert">{error}</div>}

      {coupons && coupons.length === 0 && (
        <div className="empty card">
          <div className="empty-emoji">🎫</div>
          <h3>No coupons yet</h3>
          <p className="muted">Claim a deal and it will show up here.</p>
          <Link to="/" className="btn btn-primary">Browse tonight's deals</Link>
        </div>
      )}

      {[['active', '⏳ Ready for pickup'], ['redeemed', '✅ Redeemed'], ['expired', '⌛ Expired']].map(([k, title]) =>
        groups[k].length > 0 && (
          <div key={k} className="coupon-group">
            <h3 className="group-title">{title} <span className="count">{groups[k].length}</span></h3>
            <div className="ticket-list">{groups[k].map((c) => <CouponTicket key={c.id} coupon={c} />)}</div>
          </div>
        ))}
    </section>
  )
}
