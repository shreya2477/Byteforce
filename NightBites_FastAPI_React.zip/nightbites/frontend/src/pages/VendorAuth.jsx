import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, auth } from '../api'

export default function VendorAuth() {
  const nav = useNavigate()
  const [mode, setMode] = useState('login')
  const [f, setF] = useState({ name: '', shop_name: '', email: '', password: '', phone: '', area: '', address: '' })
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  const submit = async (e) => {
    e.preventDefault()
    setBusy(true); setError('')
    try {
      const body = mode === 'login' ? { email: f.email, password: f.password } : f
      const r = await api(`/auth/${mode === 'login' ? 'login' : 'register'}`, { method: 'POST', body })
      auth.save(r.token, r.vendor)
      window.dispatchEvent(new Event('nb-auth'))
      nav('/vendor')
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  return (
    <section className="auth-wrap">
      <div className="auth-side">
        <h1>Turn tonight's leftovers into <em>revenue</em>.</h1>
        <ul className="perks">
          <li>⚡ Post a deal in 30 seconds</li>
          <li>⏳ Auto-expires at closing time or when stock ends</li>
          <li>🎟️ Customers reserve with a unique coupon code</li>
          <li>📊 Track claims, pickups & money recovered</li>
        </ul>
        <div className="demo-box">Demo vendor: <b>demo@nightbites.in</b> / <b>demo123</b></div>
      </div>
      <form className="card auth-card form" onSubmit={submit}>
        <div className="tabs">
          <button type="button" className={mode === 'login' ? 'on' : ''} onClick={() => setMode('login')}>Login</button>
          <button type="button" className={mode === 'register' ? 'on' : ''} onClick={() => setMode('register')}>Register shop</button>
        </div>
        {mode === 'register' && (
          <>
            <div className="row2">
              <label>Your name<input value={f.name} onChange={set('name')} required minLength={2} /></label>
              <label>Shop name<input value={f.shop_name} onChange={set('shop_name')} required minLength={2} /></label>
            </div>
            <div className="row2">
              <label>Phone<input value={f.phone} onChange={set('phone')} inputMode="numeric" /></label>
              <label>Area<input value={f.area} onChange={set('area')} placeholder="e.g. MP Nagar" /></label>
            </div>
            <label>Address<input value={f.address} onChange={set('address')} placeholder="Shop address for pickup" /></label>
          </>
        )}
        <label>Email<input type="email" value={f.email} onChange={set('email')} required /></label>
        <label>Password<input type="password" value={f.password} onChange={set('password')} required minLength={6} /></label>
        {error && <div className="alert">{error}</div>}
        <button className="btn btn-primary btn-block btn-lg" disabled={busy}>
          {busy ? 'Please wait…' : mode === 'login' ? 'Login to dashboard' : 'Create vendor account'}
        </button>
      </form>
    </section>
  )
}
