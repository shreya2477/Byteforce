import { useCallback, useEffect, useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import { api, auth, serverNow } from '../api'
import { rupee, timeOf, usePolling } from '../hooks'
import Countdown from '../components/Countdown'
import StockBar from '../components/StockBar'
import DealCard from '../components/DealCard'
import CouponTicket from '../components/CouponTicket'
import { useToast } from '../components/Toast'

const EMOJIS = ['🍛', '🍗', '🍱', '🥐', '🍞', '🍰', '🧁', '🍕', '🍔', '🥟', '🍲', '🥡', '🍜', '🌯', '🥪', '☕', '🍩', '🥗']
const STATUS_LABEL = { live: 'Live', sold_out: 'Sold out', expired: 'Expired', cancelled: 'Stopped' }

const toLocalInput = (ms) => {
  const d = new Date(ms); d.setSeconds(0, 0)
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16)
}

export default function VendorDashboard() {
  const nav = useNavigate()
  const toast = useToast()
  const [vendor, setVendor] = useState(auth.vendor)
  const [tab, setTab] = useState('deals')
  const [deals, setDeals] = useState([])
  const [stats, setStats] = useState(null)
  const [claimsFor, setClaimsFor] = useState(null)

  useEffect(() => {
    const sync = () => setVendor(auth.vendor)
    window.addEventListener('nb-auth', sync)
    return () => window.removeEventListener('nb-auth', sync)
  }, [])

  const load = useCallback(async () => {
    if (!auth.token) return
    try {
      const [d, s] = await Promise.all([api('/vendor/deals', { authed: true }), api('/vendor/stats', { authed: true })])
      setDeals(d.deals); setStats(s)
    } catch (e) { toast(e.message, 'err') }
  }, [toast])
  usePolling(load, 6000, [load])

  if (!vendor) return <Navigate to="/vendor/login" />

  const logout = () => { auth.clear(); window.dispatchEvent(new Event('nb-auth')); nav('/') }

  const action = async (deal, kind) => {
    try {
      if (kind === 'stock') await api(`/vendor/deals/${deal.id}`, { method: 'PATCH', authed: true, body: { add_stock: 5 } })
      if (kind === 'extend') {
        const base = Math.max(new Date(deal.closes_at).getTime(), serverNow())
        await api(`/vendor/deals/${deal.id}`, { method: 'PATCH', authed: true, body: { closes_at: new Date(base + 30 * 60000).toISOString() } })
      }
      if (kind === 'stop') {
        if (!window.confirm('Stop this deal now? Already-issued coupons stay valid.')) return
        await api(`/vendor/deals/${deal.id}/close`, { method: 'POST', authed: true })
      }
      toast(kind === 'stock' ? '+5 portions added' : kind === 'extend' ? 'Closing extended by 30 min' : 'Deal stopped')
      load()
    } catch (e) { toast(e.message, 'err') }
  }

  const live = deals.filter((d) => d.status === 'live')
  const past = deals.filter((d) => d.status !== 'live')

  return (
    <section className="page">
      <div className="dash-head">
        <div>
          <p className="eyebrow">Vendor dashboard</p>
          <h1>🏪 {vendor.shop_name}</h1>
          <p className="muted">{vendor.area} {vendor.address && `· ${vendor.address}`}</p>
        </div>
        <button className="btn btn-ghost" onClick={logout}>Logout</button>
      </div>

      <div className="stat-grid">
        <Stat icon="🟢" label="Live deals" value={stats?.live_deals} />
        <Stat icon="🎟️" label="Coupons claimed" value={stats?.claimed} />
        <Stat icon="⏳" label="Pending pickup" value={stats?.pending_pickup} />
        <Stat icon="✅" label="Redeemed" value={stats?.redeemed} />
        <Stat icon="💰" label="Revenue recovered" value={stats ? rupee(stats.revenue_recovered) : undefined} accent />
      </div>

      <div className="tabs tabs-lg">
        <button className={tab === 'deals' ? 'on' : ''} onClick={() => setTab('deals')}>📋 My deals</button>
        <button className={tab === 'new' ? 'on' : ''} onClick={() => setTab('new')}>➕ Post a deal</button>
        <button className={tab === 'redeem' ? 'on' : ''} onClick={() => setTab('redeem')}>✔️ Redeem coupon</button>
      </div>

      {tab === 'deals' && (
        <>
          {deals.length === 0 && (
            <div className="empty card">
              <div className="empty-emoji">🍽️</div>
              <h3>No deals yet</h3>
              <p className="muted">Post your surplus food before closing time.</p>
              <button className="btn btn-primary" onClick={() => setTab('new')}>Post your first deal</button>
            </div>
          )}
          {live.length > 0 && <h3 className="group-title">Live now <span className="count">{live.length}</span></h3>}
          <div className="vdeal-list">
            {live.map((d) => <VendorDealRow key={d.id} d={d} onAction={action} onClaims={() => setClaimsFor(d)} />)}
          </div>
          {past.length > 0 && <h3 className="group-title">Ended <span className="count">{past.length}</span></h3>}
          <div className="vdeal-list">
            {past.map((d) => <VendorDealRow key={d.id} d={d} onAction={action} onClaims={() => setClaimsFor(d)} />)}
          </div>
        </>
      )}

      {tab === 'new' && <NewDeal vendor={vendor} onCreated={() => { setTab('deals'); load() }} />}
      {tab === 'redeem' && <Redeem onDone={load} />}
      {claimsFor && <ClaimsModal deal={claimsFor} onClose={() => setClaimsFor(null)} />}
    </section>
  )
}

function Stat({ icon, label, value, accent }) {
  return (
    <div className={`card stat ${accent ? 'stat-accent' : ''}`}>
      <span className="stat-icon">{icon}</span>
      <b>{value ?? '–'}</b>
      <span className="muted small">{label}</span>
    </div>
  )
}

function VendorDealRow({ d, onAction, onClaims }) {
  const live = d.status === 'live'
  return (
    <div className={`card vdeal ${live ? '' : 'is-off'}`}>
      <div className="vdeal-emoji">{d.emoji}</div>
      <div className="vdeal-info">
        <div className="row gap-sm wrap">
          <h4>{d.title}</h4>
          <span className={`status-pill s-${d.status}`}>{STATUS_LABEL[d.status]}</span>
        </div>
        <p className="muted small">{rupee(d.deal_price)} <s>{rupee(d.original_price)}</s> · {d.discount_pct}% off · closes {timeOf(d.closes_at)} · {d.redeemed} picked up</p>
        <StockBar remaining={d.remaining_stock} total={d.total_stock} />
      </div>
      <div className="vdeal-cd">{live ? <Countdown to={d.closes_at} /> : <span className="muted small">Ended</span>}</div>
      <div className="vdeal-actions">
        <button className="btn btn-sm btn-ghost" onClick={onClaims}>👥 Claims ({d.claimed})</button>
        {d.status !== 'cancelled' && d.status !== 'expired' && <button className="btn btn-sm btn-ghost" onClick={() => onAction(d, 'stock')}>+5 stock</button>}
        {d.status !== 'cancelled' && <button className="btn btn-sm btn-ghost" onClick={() => onAction(d, 'extend')}>+30 min</button>}
        {live && <button className="btn btn-sm btn-danger" onClick={() => onAction(d, 'stop')}>Stop</button>}
      </div>
    </div>
  )
}

function NewDeal({ vendor, onCreated }) {
  const toast = useToast()
  const [f, setF] = useState({
    title: '', description: '', category: 'Biryani', emoji: '🍛', veg: true,
    original_price: '', deal_price: '', total_stock: 10, max_per_customer: 1, pickup_minutes: 30,
    closes_local: toLocalInput(serverNow() + 90 * 60000), image_url: '',
  })
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value })
  const quick = (mins) => setF({ ...f, closes_local: toLocalInput(serverNow() + mins * 60000) })

  const closesIso = f.closes_local ? new Date(f.closes_local).toISOString() : new Date().toISOString()
  const op = Number(f.original_price) || 0
  const dp = Number(f.deal_price) || 0
  const preview = {
    id: 0, title: f.title || 'Your dish name', description: f.description, category: f.category, emoji: f.emoji,
    image_url: f.image_url, veg: f.veg, original_price: op, deal_price: dp,
    discount_pct: op ? Math.max(0, Math.round((1 - dp / op) * 100)) : 0,
    total_stock: Number(f.total_stock) || 0, remaining_stock: Number(f.total_stock) || 0,
    pickup_minutes: Number(f.pickup_minutes) || 30, closes_at: closesIso, status: 'live',
    vendor: { shop_name: vendor.shop_name, area: vendor.area },
  }

  const submit = async (e) => {
    e.preventDefault(); setError('')
    if (dp >= op) return setError('Deal price must be lower than original price')
    setBusy(true)
    try {
      await api('/vendor/deals', {
        method: 'POST', authed: true,
        body: {
          title: f.title, description: f.description, category: f.category, emoji: f.emoji, veg: f.veg,
          image_url: f.image_url, original_price: op, deal_price: dp, total_stock: Number(f.total_stock),
          max_per_customer: Number(f.max_per_customer), pickup_minutes: Number(f.pickup_minutes), closes_at: closesIso,
        },
      })
      toast('Deal is live! 🎉')
      onCreated()
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  return (
    <div className="new-deal">
      <form className="card form" onSubmit={submit}>
        <label>Dish / box name<input value={f.title} onChange={set('title')} required minLength={3} placeholder="e.g. Chicken Biryani (Full)" /></label>
        <label>Description<textarea rows={2} value={f.description} onChange={set('description')} placeholder="What's included, freshness, portion size…" /></label>
        <div className="row2">
          <label>Category
            <select value={f.category} onChange={set('category')}>
              {['Biryani', 'Bakery', 'Pizza', 'Street Food', 'Desserts', 'Thali', 'Chinese', 'Cafe', 'Other'].map((c) => <option key={c}>{c}</option>)}
            </select>
          </label>
          <label className="switch switch-field">
            <input type="checkbox" checked={f.veg} onChange={set('veg')} />
            <span className="switch-ui" /> {f.veg ? '🟢 Veg' : '🔴 Non-veg'}
          </label>
        </div>
        <div className="field">
          <span className="field-label">Icon</span>
          <div className="emoji-pick">
            {EMOJIS.map((em) => <button type="button" key={em} className={f.emoji === em ? 'on' : ''} onClick={() => setF({ ...f, emoji: em })}>{em}</button>)}
          </div>
        </div>
        <div className="row3">
          <label>Original price (₹)<input type="number" min="1" value={f.original_price} onChange={set('original_price')} required /></label>
          <label>Deal price (₹)<input type="number" min="0" value={f.deal_price} onChange={set('deal_price')} required /></label>
          <label>Portions<input type="number" min="1" max="1000" value={f.total_stock} onChange={set('total_stock')} required /></label>
        </div>
        <div className="field">
          <span className="field-label">Closing time (deal auto-expires)</span>
          <div className="row gap-sm wrap">
            {[30, 60, 120, 180].map((m) => <button type="button" key={m} className="btn btn-sm btn-ghost" onClick={() => quick(m)}>+{m >= 60 ? `${m / 60}h` : `${m}m`}</button>)}
            <input type="datetime-local" value={f.closes_local} onChange={set('closes_local')} required className="grow" />
          </div>
        </div>
        <div className="row3">
          <label>Max per customer<input type="number" min="1" max="10" value={f.max_per_customer} onChange={set('max_per_customer')} /></label>
          <label>Pickup window (min)<input type="number" min="5" max="180" value={f.pickup_minutes} onChange={set('pickup_minutes')} /></label>
          <label>Image URL (optional)<input value={f.image_url} onChange={set('image_url')} placeholder="https://…" /></label>
        </div>
        {error && <div className="alert">{error}</div>}
        <button className="btn btn-primary btn-lg btn-block" disabled={busy}>{busy ? 'Publishing…' : '🚀 Publish deal'}</button>
      </form>
      <div className="preview">
        <p className="eyebrow">Live preview</p>
        <DealCard deal={preview} onClaim={() => {}} />
      </div>
    </div>
  )
}

function Redeem({ onDone }) {
  const toast = useToast()
  const [code, setCode] = useState('')
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e) => {
    e.preventDefault(); setError(''); setResult(null); setBusy(true)
    try {
      const r = await api('/vendor/redeem', { method: 'POST', authed: true, body: { code } })
      setResult(r.coupon); setCode(''); toast('Coupon redeemed ✅'); onDone()
    } catch (err) { setError(err.message) } finally { setBusy(false) }
  }

  return (
    <div className="redeem card">
      <h3>Verify customer coupon</h3>
      <p className="muted">Ask the customer for their code (e.g. NB-7K2QXM), then collect payment.</p>
      <form onSubmit={submit} className="redeem-form">
        <input className="code-input" value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} placeholder="NB-XXXXXX" required />
        <button className="btn btn-primary btn-lg" disabled={busy}>{busy ? 'Checking…' : 'Redeem'}</button>
      </form>
      {error && <div className="alert">{error}</div>}
      {result && (
        <div className="redeem-ok">
          <p>✅ Valid! Hand over the order to <b>{result.customer_name}</b> ({result.customer_phone}) and collect <b>{rupee(result.deal.deal_price)}</b>.</p>
          <CouponTicket coupon={result} compact />
        </div>
      )}
    </div>
  )
}

function ClaimsModal({ deal, onClose }) {
  const [data, setData] = useState(null)
  useEffect(() => {
    api(`/vendor/deals/${deal.id}/coupons`, { authed: true }).then(setData).catch(() => setData({ coupons: [] }))
  }, [deal.id])
  return (
    <div className="modal-bg" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal modal-wide">
        <button className="modal-x" onClick={onClose}>×</button>
        <h2>{deal.emoji} {deal.title}</h2>
        <p className="muted">{deal.claimed} claimed of {deal.total_stock}</p>
        {!data ? <p className="muted">Loading…</p> : data.coupons.length === 0 ? <p className="muted">No claims yet.</p> : (
          <table className="table">
            <thead><tr><th>Code</th><th>Customer</th><th>Phone</th><th>Claimed</th><th>Status</th></tr></thead>
            <tbody>
              {data.coupons.map((c) => (
                <tr key={c.id}>
                  <td className="mono">{c.code}</td><td>{c.customer_name}</td><td>{c.customer_phone}</td>
                  <td>{timeOf(c.created_at)}</td><td><span className={`status-pill s-${c.status}`}>{c.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
